import React from "react";
import SpaceBattle from "./SpaceBattle";
function App ()
{
	return (
		<>
			Space Battle!
		</>
	);
}

export default App;
