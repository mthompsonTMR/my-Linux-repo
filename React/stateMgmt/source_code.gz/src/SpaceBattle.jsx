import React, { useState } from "react";
import CardContent from "@/components/ui/CardContent";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
//note @symbol on imports is path alias replacing deep relative paths with much cleaner results.  Vite.config.js is used to resolve alias.  Vite framework with JS extension will work the same in React.  
//since Vite was modified to use alias imports need to alos be declared in main JSX.
const SpaceBattle = ({ maxDamage = 20 }) => {
  const [playerHealth, setPlayerHealth] = useState(100);
  const [enemyHealth, setEnemyHealth] = useState(100);
  const [gameStatus, setGameStatus] = useState("active");

  const fire = () => {
    if (gameStatus !== "active") return;

    const playerDamage = Math.floor(Math.random() * maxDamage) + 1;
    const enemyDamage = Math.floor(Math.random() * maxDamage) + 1;

    const newPlayerHealth = Math.max(playerHealth - enemyDamage, 0);
    const newEnemyHealth = Math.max(enemyHealth - playerDamage, 0);

    setPlayerHealth(newPlayerHealth);
    setEnemyHealth(newEnemyHealth);

    if (newPlayerHealth === 0 && newEnemyHealth === 0) {
      setGameStatus("draw");
    } else if (newPlayerHealth === 0) {
      setGameStatus("lost");
    } else if (newEnemyHealth === 0) {
      setGameStatus("won");
    }
  };

  const restartGame = () => {
    setPlayerHealth(100);
    setEnemyHealth(100);
    setGameStatus("active");
  };

  return (
    <div className="flex flex-col items-center p-4">
      <h1 className="text-2xl font-bold">🚀 Space Battle Simulator</h1>
      <Card className="w-96 text-center mt-4 p-4 border">
        <CardContent>
          <p>💥 Player Health: {playerHealth} ❤️‍🩹</p>
          <p>👾 Enemy Health: {enemyHealth} ❤️‍🩹</p>
          {gameStatus === "active" ? (
            <Button className="mt-4" onClick={fire}>☄️ Fire!</Button>
          ) : (
            <>
              <p className="mt-4 font-bold">
                {gameStatus === "won" ? "🎉 You Won!" : gameStatus === "lost" ? "😞 You Lost!" : "🤝 It's a Draw!"}
              </p>
              <Button className="mt-4" onClick={restartGame}>🔄 Restart</Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default SpaceBattle;

