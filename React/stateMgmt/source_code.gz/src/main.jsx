import React from "react";
import ReactDOM from "react-dom/client";
import SpaceBattle from "./SpaceBattle"; // Ensure correct path
import "./index.css"; // Ensure styles are loaded
//since Vite was modified to use alias imports need to be declared in here in main JSX.
ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <SpaceBattle />
  </React.StrictMode>
);

