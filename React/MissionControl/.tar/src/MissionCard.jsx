import React from "react";


import MissionAction from "./MissionAction";

const MissionCard = ({ mission, updateMissionStatus }) => {
    return (
        <div className="mission-card">
            <h2>{mission.name}</h2>
            <p><strong>Status:</strong> {mission.status}</p>
            <p><strong>Crew:</strong> {mission.crew.length > 0 ? mission.crew.join(", ") : "No crew assigned"}</p>
            <MissionAction missionId={mission.id} updateMissionStatus={updateMissionStatus} />
        </div>
    );
};


export default MissionCard;