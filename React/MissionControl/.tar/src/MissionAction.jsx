import React from "react";

const MissionAction = ({missionId, updateMissionStatus}) => {

  return (
    <div className="mission-actions" >
      
      <button className ="launch-button" onClick={() => updateMissionStatus(missionId, "In Progress")}>
       Launch
      </button>
      
      <button className="complete-button" onClick={()=> updateMissionStatus(missionId, "Completed")}>
        Complete
      </button>
    </div>
  )
}

export default MissionAction;