import React from "react";
import MissionControl from './MissionControl'

function App() {
     return (
        <div>
            <h1>Welcome to Space Mission Control</h1>
            <MissionControl />
        </div>
    );
}

export default App;