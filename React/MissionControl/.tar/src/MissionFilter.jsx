import React from "react";

const MissionFilter = ({ setFilter}) => {
  return(
    <div className="status-filter">
      <button onClick={() => setFilter("All")} className="filter-button">All</button> 
      <button onClick={() => setFilter("Planned")} className="filter-button">Planned</button> 
      <button onClick={() => setFilter("Active")} className="filter-button">Active</button> 
      <button onClick={() => setFilter("Completed")} className="filter-button">Completed</button> 
    </div>
  );
};

export default MissionFilter;